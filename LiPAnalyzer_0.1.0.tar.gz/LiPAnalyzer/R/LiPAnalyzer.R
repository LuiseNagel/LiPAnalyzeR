#' LiP Analyzer
#'
#' Blabla long discription blabla
#'
#' @docType package
#'
#' @author Luise Nagel \email{lnagel6@uni-koeln.de}
#'
#' @name LiPAnalyzer
NULL
